import 'package:flutter/material.dart';

const supportedLocales = [
  Locale('ar'),
  Locale('en'),
  Locale('fr'),
  // Add more as needed
];