class IntegrationService {
  static String exportToCSV(List<Map<String, dynamic>> data) {
    // نفس الكود السابق في CSVHelper
    return '';
  }

  static Future<void> sendReportByEmail(String csvData, String email) async {
    // استخدم package مثل url_launcher/mailto
  }
}