class VoiceAIService {
  static Future<String> listenAndAnalyze() async {
    // logic: استمع لصوت المستخدم، حلله، أعد اقتراحًا أو نفذ أمرًا
    return "مصروف بقيمة 100 ريال مضاف لتصنيف المطاعم";
  }
}